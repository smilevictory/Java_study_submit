package ch06.sec07.exam01;

public class Car {

    // 필드
    String name;
    String color;
    int displacement;

    // 기본 생성자
    public Car(String name, String color, int displacement) {
        this.name = name;
        this.color = color;
        this.displacement = displacement;


    }

}